package vista;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import modelo.Alumno;

public class Instituto {
			
	public static void main(String[] args) {
		Alumno alumnoDavid = new Alumno("David", 33);
		Alumno alumnoJose = new Alumno("Jose", 32);		
		
		System.out.println("Hola mundo!!!");
		
		System.out.println("============================================");
		//IMPRIMIENDEO MIS ALUMNOS
		System.out.println("Nombre: "+alumnoDavid.getName());
		System.out.println("Edad: "+alumnoDavid.getEdad());
		
		System.out.println("Nombre: "+alumnoJose.getName());
		System.out.println("Edad: "+alumnoJose.getEdad());
		
		System.out.println("============================================");
		
		//AGREGANDO ALUMMNOS A LA LISTA
		
		List<Alumno> miListaAlumno = new ArrayList<Alumno>();
		
		miListaAlumno.add(alumnoDavid);
		miListaAlumno.add(alumnoJose);
		
		for (Iterator iterator = miListaAlumno.iterator(); iterator.hasNext();) {
			Alumno alumno = (Alumno) iterator.next();
			
			
			System.out.println("Nombre: "+alumno.getName());
			System.out.println("Nombre: "+alumno.getEdad());
		}
		
	}
}
